/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package timetablemgt;

import java.awt.event.MouseEvent;
import java.net.URL;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javax.swing.JOptionPane;

/**
 *
 * @author Damika
 */
public class statisticsController implements Initializable {
    
    
    @FXML
    private TableColumn<analysisdata, String> tvpract;

    @FXML
    private TableColumn<analysisdata, String> tvlostpract;

    @FXML
    private TableColumn<analysisdata, String> tvklec;

    @FXML
    private TableView<analysisdata> table_stat;

    @FXML
    private TableColumn<analysisdata, String> tvlostlec;

    @FXML
    private TableColumn<analysisdata, String> tvgid;

    @FXML
    private TableColumn<analysisdata, String> tvsubj;

    @FXML
    private TableColumn<analysisdata, String> tvmf;

    @FXML
    private TableColumn<analysisdata, String> tvmt;
    
    
    
    @FXML
    private TextField txtpract;

    @FXML
    private TextField txtlostpract;
    
    @FXML
    private TextField asmf;
        
    @FXML
    private TextField asmt;

    @FXML
    private TextField txtgrpid;

    @FXML
    private TextField txtlec;
    
    @FXML
    private TextField txtsubj;

    @FXML
    private TextField txtlostlect;
    
    @FXML
    private TextField filterfield;
    
    
    
    ObservableList<analysisdata> listM;
    ObservableList<analysisdata> dataList;
     
    int index = -1;
    
    Connection conn =null;
    ResultSet rs = null;
    PreparedStatement pst = null;
    
    
    public void save_stat (){    
        conn = mysqlconnector.ConnectDb();
        String sql = "insert into analysisdata (Group ID,Month From,Month To,Subject,No of lectures,No of lost lectures,No of practicals,No of lost practicals)values(?,?,?,?,?,?,?,? )";

        try {
            pst = conn.prepareStatement(sql);
            pst.setString(1, txtgrpid.getText());
            pst.setString(2, asmf.getText());
            pst.setString(3, asmt.getText());
            pst.setString(4, txtsubj.getText());
            pst.setString(5, txtlec.getText());
            pst.setString(6, txtlostlect.getText());
            pst.setString(7, txtpract.getText());
            pst.setString(8, txtlostpract.getText());
            pst.execute();
            
            JOptionPane.showMessageDialog(null, "Analysis Data Add succes");
            UpdateTable();
            search_user();
        } catch (Exception e) {
            
            JOptionPane.showMessageDialog(null, e);
          
        }
    }
    
    
    @FXML
    void getSelected (MouseEvent event){
        index = table_stat.getSelectionModel().getSelectedIndex();
        if (index <= -1){
    
            return;
    }
        txtgrpid.setText(tvgid.getCellData(index).toString());
        asmf.setText(tvmf.getCellData(index).toString());
        asmt.setText(tvmt.getCellData(index).toString());
        txtsubj.setText(tvsubj.getCellData(index).toString());
        txtlec.setText(tvklec.getCellData(index).toString());
        txtlostlect.setText(tvlostlec.getCellData(index).toString());
        txtpract.setText(tvpract.getCellData(index).toString());
        txtlostpract.setText(tvlostpract.getCellData(index).toString());
    
    }
    
    
    public void Edit (){   
        try {
            conn = mysqlconnector.ConnectDb();
            String value1 = txtgrpid.getText();
            String value2 = asmf.getText();
            String value3 = asmt.getText();
            String value4 = txtsubj.getText();
            String value5 = txtlec.getText();
            String value6 = txtlostlect.getText();
            String value7 = txtpract.getText();
            String value8 = txtlostpract.getText();
            String sql = "update analysisdata set Group ID= '"+value1+"',Month From= '"+value2+"',Month To= '"+value3+"',Subject= '"+value4+"',No of lectures= '"+value5+"',No of lost lectures= '"+value6+"',No of practicals= '"+value7+"',No of lost practicals= '"+value8+"' where Group ID='"+value1+"' ";
            pst= conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Update");
            UpdateTable();
            search_user();
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
        
    }
    
    public void Delete(){
        
        conn = mysqlconnector.ConnectDb();
        String sql = "delete from analysisdata where Group ID = ?";
            try {
                pst = conn.prepareStatement(sql);
                pst.setString(1, txtgrpid.getText());
                pst.execute();
                JOptionPane.showMessageDialog(null, "Delete");
                UpdateTable();
                search_user();
            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }
    
    }
    
    
    public void UpdateTable(){
         
        tvgid.setCellValueFactory(new PropertyValueFactory<analysisdata,String>("grpid"));
        tvmf.setCellValueFactory(new PropertyValueFactory<analysisdata,String>("mfrom"));
        tvmt.setCellValueFactory(new PropertyValueFactory<analysisdata,String>("mto"));
        tvsubj.setCellValueFactory(new PropertyValueFactory<analysisdata,String>("sbj"));
        tvklec.setCellValueFactory(new PropertyValueFactory<analysisdata,String>("lect"));
        tvlostlec.setCellValueFactory(new PropertyValueFactory<analysisdata,String>("lostlec"));
        tvpract.setCellValueFactory(new PropertyValueFactory<analysisdata,String>("pract"));
        tvlostpract.setCellValueFactory(new PropertyValueFactory<analysisdata,String>("lostpract"));
        
        listM = mysqlconnector.getDatausers();
        table_stat.setItems(listM);
         
         
    }
    
    
    @FXML
    void search_user() {   
        
        tvgid.setCellValueFactory(new PropertyValueFactory<analysisdata,String>("grpid"));
        tvmf.setCellValueFactory(new PropertyValueFactory<analysisdata,String>("mfrom"));
        tvmt.setCellValueFactory(new PropertyValueFactory<analysisdata,String>("mto"));
        tvsubj.setCellValueFactory(new PropertyValueFactory<analysisdata,String>("sbj"));
        tvklec.setCellValueFactory(new PropertyValueFactory<analysisdata,String>("lect"));
        tvlostlec.setCellValueFactory(new PropertyValueFactory<analysisdata,String>("lostlec"));
        tvpract.setCellValueFactory(new PropertyValueFactory<analysisdata,String>("pract"));
        tvlostpract.setCellValueFactory(new PropertyValueFactory<analysisdata,String>("lostpract"));
             
        dataList = mysqlconnector.getDatausers();
        table_stat.setItems(dataList);
        FilteredList<analysisdata> filteredData = new FilteredList<>(dataList, b -> true);  
        filterfield.textProperty().addListener((observable, oldValue, newValue) -> {
        filteredData.setPredicate(data -> {
            if (newValue == null || newValue.isEmpty()) {
                return true;
            }         
    
            String lowerCaseFilter = newValue.toLowerCase();
            if (data.getGrpid().toLowerCase().indexOf(lowerCaseFilter) != -1 ) {
                return true; // Filter matches username
            } else if (data.getMfrom().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                return true; // Filter matches password
            } else if (data.getMto().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                return true; // Filter matches password
            } else if (data.getSbj().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                return true; // Filter matches password
            } else if (data.getLect().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                return true; // Filter matches password
            }else if (data.getLostlec().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                return true; // Filter matches password
            }else if (data.getPract().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                return true; // Filter matches password
            }else if (String.valueOf(data.getLostpract()).indexOf(lowerCaseFilter)!=-1)
                return true;// Filter matches email               
                else  
                    return false; // Does not match.
            
            
            });
        });
        
        SortedList<analysisdata> sortedData = new SortedList<>(filteredData);  
        sortedData.comparatorProperty().bind(table_stat.comparatorProperty());  
        table_stat.setItems(sortedData);      
    }
     
     
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        UpdateTable();
        search_user();

    } 
    
    
    public void changeScreen(javafx.event.ActionEvent event) {
        try{
            Parent tableViewParent = FXMLLoader.load(getClass().getResource("../main.fxml"));
            Scene tableViewScene = new Scene(tableViewParent);
            Stage window =(Stage)((Node)event.getSource()).getScene().getWindow();
            window.setScene(tableViewScene);
            window.show();
        }catch(Exception E){
            System.out.println(E);
        }
    }
    
}
