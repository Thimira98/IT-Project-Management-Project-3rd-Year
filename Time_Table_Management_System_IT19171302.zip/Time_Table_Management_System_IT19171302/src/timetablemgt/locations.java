/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package timetablemgt;

import javafx.scene.control.RadioButton;

/**
 *
 * @author Damika
 */
public class locations {
    
    int id, capacity;

    public locations(int id) {
        this.id = id;
    }
    String Bname, Rname, roomtype;

    public locations(int capacity, String Bname, String Rname, String roomtype) {
        this.capacity = capacity;
        this.Bname = Bname;
        this.Rname = Rname;
        this.roomtype = roomtype;
    }

    public int getId() {
        return id;
    }

    public int getCapacity() {
        return capacity;
    }

    public String getBname() {
        return Bname;
    }

    public String getRname() {
        return Rname;
    }

    public String getRoomtype() {
        return roomtype;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public void setBname(String Bname) {
        this.Bname = Bname;
    }

    public void setRname(String Rname) {
        this.Rname = Rname;
    }

    public void setRoomtype(String roomtype) {
        this.roomtype = roomtype;
    }
    
    
    
    
    
}
