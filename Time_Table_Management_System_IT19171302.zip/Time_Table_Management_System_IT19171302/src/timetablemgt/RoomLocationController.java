/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package timetablemgt;

import java.awt.TextField;
import java.awt.event.MouseEvent;
import java.net.URL;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.collections.transformation.SortedList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.ToggleButton;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;
import javax.swing.JOptionPane;
import static timetablemgt.mysqlconnector.ConnectDb;

/**
 * FXML Controller class
 *
 * @author Damika
 */
public class RoomLocationController implements Initializable {

    @FXML
    private TableColumn<locations, String> tvlocrname;

    @FXML
    private TableColumn<locations, String> tvlocbname;

    @FXML
    private TableColumn<locations, String> tvrromtype;

    @FXML
    private TableView<locations> tvloc;

    @FXML
    private TableColumn<locations, Integer> tvcap;

    @FXML
    private TableColumn<locations, Integer> roomID;

    @FXML
    private TextField CAPTXT;

    @FXML
    private TextField roomid;

    @FXML
    private RadioButton LABRB;

    @FXML
    private TextField BNtxt;

    @FXML
    private RadioButton LecRB;

    @FXML
    private TextField RNTxt;


    @FXML
    private TextField filterloc;


    ObservableList<locations> listL;
    ObservableList<locations> dataList;


    int index = -1;

    Connection conn =null;
    ResultSet rs = null;
    PreparedStatement pst = null;

    public void Add_locations (){
        conn = mysqlconnector.ConnectDb();
        String sql = "insert into locations (BuildingName,RoomName,Capacity,RoomType,roomID)values(?,?,?,?,? )";
        try {
            pst = conn.prepareStatement(sql);
            pst.setString(1, BNtxt.getText());
            pst.setString(2, RNTxt.getText());
            pst.setString(3, CAPTXT.getText());
            pst.setString(4, roomid.getText());
            pst.execute();


            JOptionPane.showMessageDialog(null, "Locations Add succes");
            UpdateTable();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }
    }

    @FXML
    void getSelected (MouseEvent event){
        index = tvloc.getSelectionModel().getSelectedIndex();
        if (index <= -1){

            return;
        }

        BNtxt.setText(tvlocrname.getCellData(index).toString());
        RNTxt.setText(tvlocbname.getCellData(index).toString());
        CAPTXT.setText(tvcap.getCellData(index).toString());
        roomid.setText(roomID.getCellData(index).toString());

    }

    public void Edit (){
        try {
            conn = mysqlconnector.ConnectDb();
            String value1 = tvlocrname.getText();
            String value2 = tvlocbname.getText();
            String value3 = tvcap.getText();
            String value4 = roomID.getText();

            String sql = "update locations set BuildingName= '"+value1+"',RoomName= '"+value2+"',Capacity= '"+value3+"',roomID= '"+value4+"' where roomID='"+value4+"' ";
            pst= conn.prepareStatement(sql);
            pst.execute();
            JOptionPane.showMessageDialog(null, "Update");
            UpdateTable();

        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
        }

    }

    public void Delete(){

        conn = mysqlconnector.ConnectDb();
        String sql = "delete from locations where roomID = ?";
            try {
                pst = conn.prepareStatement(sql);
                pst.setString(1, roomid.getText());
                pst.execute();
                JOptionPane.showMessageDialog(null, "Delete");
                UpdateTable();

            } catch (Exception e) {
                JOptionPane.showMessageDialog(null, e);
            }

    }

    public void UpdateTable(){

        tvlocrname.setCellValueFactory(new PropertyValueFactory<locations,String>("Rname"));
        tvlocbname.setCellValueFactory(new PropertyValueFactory<locations,String>("Bname"));
        tvcap.setCellValueFactory(new PropertyValueFactory<locations,Integer>("capacity"));
        tvrromtype.setCellValueFactory(new PropertyValueFactory<locations,String>("roomtype"));
        roomID.setCellValueFactory(new PropertyValueFactory<locations,Integer>("roomID"));

        listL = mysqlconnector.getDataLoc();
        tvloc.setItems(listL);
    }

    /*
    @FXML
    void search_loc() {

        tvlocrname.setCellValueFactory(new PropertyValueFactory<locations,String>("Rname"));
        tvlocbname.setCellValueFactory(new PropertyValueFactory<locations,String>("Bname"));
        tvcap.setCellValueFactory(new PropertyValueFactory<locations,Integer>("capacity"));
        tvrromtype.setCellValueFactory(new PropertyValueFactory<locations,String>("roomtype"));
        roomID.setCellValueFactory(new PropertyValueFactory<locations,Integer>("roomID"));


        dataList = mysqlconnector.getDataLoc();
        tvloc.setItems(dataList);
        FilteredList<locations> filteredData = new FilteredList<>(dataList, b -> true);
        filterloc.textProperty().addListener((observable, oldValue, newValue) -> {
        filteredData.setPredicate(data -> {
            if (newValue == null || newValue.isEmpty()) {
                return true;
            }

            String lowerCaseFilter = newValue.toLowerCase();
            if (data.getGrpid().toLowerCase().indexOf(lowerCaseFilter) != -1 ) {
                return true; // Filter matches username
            } else if (data.getMfrom().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                return true; // Filter matches password
            } else if (data.getMto().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                return true; // Filter matches password
            } else if (data.getSbj().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                return true; // Filter matches password
            } else if (data.getLect().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                return true; // Filter matches password
            }else if (data.getLostlec().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                return true; // Filter matches password
            }else if (data.getPract().toLowerCase().indexOf(lowerCaseFilter) != -1) {
                return true; // Filter matches password
            }else if (String.valueOf(data.getLostpract()).indexOf(lowerCaseFilter)!=-1)
                return true;// Filter matches email
                else
                    return false; // Does not match.


            });
        });

        SortedList<locations> sortedData = new SortedList<>(filteredData);
        sortedData.comparatorProperty().bind(tvloc.comparatorProperty());
        tvloc.setItems(sortedData);
    }
    */

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
        UpdateTable();


    }



    public void changeScreen(javafx.event.ActionEvent event) {
        try{
            Parent tableViewParent = FXMLLoader.load(getClass().getResource("../main.fxml"));
            Scene tableViewScene = new Scene(tableViewParent);
            Stage window =(Stage)((Node)event.getSource()).getScene().getWindow();
            window.setScene(tableViewScene);
            window.show();
        }catch(Exception E){
            System.out.println(E);
        }
    }

}
