/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package timetablemgt;

/**
 *
 * @author Damika
 */
public class analysisdata {
    
    String grpid, mfrom, mto, sbj, lect, lostlec, pract, lostpract;

    public analysisdata(String grpid, String mfrom, String mto, String sbj, String lect, String lostlec, String pract, String lostpract) {
        this.grpid = grpid;
        this.mfrom = mfrom;
        this.mto = mto;
        this.sbj = sbj;
        this.lect = lect;
        this.lostlec = lostlec;
        this.pract = pract;
        this.lostpract = lostpract;
    }

    analysisdata(String string, String string0, String string1, String string2, String string3) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String getGrpid() {
        return grpid;
    }

    public String getMfrom() {
        return mfrom;
    }

    public String getMto() {
        return mto;
    }

    public String getSbj() {
        return sbj;
    }

    public String getLect() {
        return lect;
    }

    public String getLostlec() {
        return lostlec;
    }

    public String getPract() {
        return pract;
    }

    public String getLostpract() {
        return lostpract;
    }

    public void setGrpid(String grpid) {
        this.grpid = grpid;
    }

    public void setMfrom(String mfrom) {
        this.mfrom = mfrom;
    }

    public void setMto(String mto) {
        this.mto = mto;
    }

    public void setSbj(String sbj) {
        this.sbj = sbj;
    }

    public void setLect(String lect) {
        this.lect = lect;
    }

    public void setLostlec(String lostlec) {
        this.lostlec = lostlec;
    }

    public void setPract(String pract) {
        this.pract = pract;
    }

    public void setLostpract(String lostpract) {
        this.lostpract = lostpract;
    }
    
    
    
}
