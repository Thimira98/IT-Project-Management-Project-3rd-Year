/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package timetablemgt;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javax.swing.JOptionPane;

/**
 *
 * @author Damika
 */
public class mysqlconnector {
    
    Connection conn = null;
    public static Connection ConnectDb(){
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection conn = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/time","root","damikagd1");
           // JOptionPane.showMessageDialog(null, "Connection Established");
            return conn;
        } catch (Exception e) {
            JOptionPane.showMessageDialog(null, e);
            return null;
        }
    }
    
    
    public static ObservableList<analysisdata> getDatausers(){
        Connection conn = ConnectDb();
        ObservableList<analysisdata> list = FXCollections.observableArrayList();
        try {
            PreparedStatement ps = conn.prepareStatement("select * from analysisdata");
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()){   
                list.add(new analysisdata(rs.getString("grpid"), rs.getString("mfrom"), rs.getString("mto"), rs.getString("sbj"), rs.getString("lect"),rs.getString("lostlec"),rs.getString("pract"),rs.getString("lostpract")));             
            }
        } catch (Exception e) {
        }
        return list;
    }
    
        public static ObservableList<locations> getDataLoc(){
        Connection conn = ConnectDb();
        ObservableList<locations> list = FXCollections.observableArrayList();
        try {
            PreparedStatement ps = conn.prepareStatement("select * from roomlocations");
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()){   
                list.add(new locations(Integer.parseInt(rs.getString("capacity")),rs.getString("Bname"), rs.getString("Rname"), rs.getString("roomtype")));             
            }
        } catch (Exception e) {
        }
        return list;
    }
    
}
